## 主要结果

- `data/dataset.csv`：样本总表，共 803 行，记录类别、数据划分、图片路径、未知字节比例和质量等级。
- `data/images/`：803 张灰度主图，供 CNN、Swin 和 ViT 使用。
- `data/features/features.csv`：803 个样本的 355 个静态特征。
- `data/manifests/quality.csv`：样本质量标记。
- `data/manifests/removed_features.csv`：删除的 9 个常量特征。
- `data/manifests/duplicate_labels.csv`：原始标签中的重复记录。
- `data/manifests/classes.csv`：类别编号与恶意软件家族名称。
- `data/reports/summary.json`：提交内容的处理统计。
- `data/reports/check.json`：提交内容的检查记录。

`scripts/` 中是完整处理代码：`preprocess.py` 负责配对、去重、划分和特征提取；`make_images.py` 负责生成主图；`finish.py` 负责常量特征清理、质量标记和总表；`check.py` 负责最终检查。

`config.json` 保存划分与图片规则，`environment.yml` 保存运行环境。

## 处理结果

- 原始标签 900 行，其中 63 组 ID 重复；删除 97 条多余记录后保留 803 个样本。
- 9 个类别，train、val、test 分别为 562、120、121 个样本。
- 删除 9 个对分类没有作用的常量特征，最终保留 355 个输入特征。
- 清洗后的主表和特征表没有缺失值、无穷值或重复 ID。
- 质量等级为 normal 525 个、caution 188 个、review 90 个；质量标记用于复查，没有直接删除样本。

主图是把完整 `.bytes` 字节序列等分为 1024 段，再把每段已知字节的平均值排成 32×32 灰度图。完整工作目录中还生成了前 1024 字节对照图和未知字节 mask；它们不是模型的必需输入，所以没有放进这个提交文件夹。

## 环境和运行

```powershell
conda env update -n 你的环境 -f environment.yml
conda activate 你的环境
python scripts/preprocess.py
python scripts/make_images.py
python scripts/finish.py
python scripts/check.py
```
完整运行会另外生成 `images_head/`、`masks/`、`samples.csv`、`image_records.csv`、`class_counts.csv` 和 `image_summary.json`。不能直接单独运行 `check.py`，要先依次完成前面三个处理脚本；最后确认 `data/reports/check.json` 中的 `passed` 为 `true`。

## 使用

图像模型读取 `data/dataset.csv` 和 `data/images/`。传统机器学习或特征融合读取 `data/features/features.csv`，并按 `dataset.csv` 中的 split 划分。`Id` 只用于匹配样本，`Class` 是标签，都不能作为输入特征。
